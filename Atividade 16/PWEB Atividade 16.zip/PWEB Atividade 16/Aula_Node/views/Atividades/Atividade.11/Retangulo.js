var base = prompt("✏️ Digite o valor da base: ");
var altura = prompt("✏️ Digite o valor da altura: ");
var retangulo = {};

retangulo.altura = altura;
retangulo.base = base;
var area = `📐 Área do retangulo= ${retangulo.base * retangulo.altura}M2`;

var any = document.querySelector().value;
