/* Comando para rodar o programa: 
 npm init -y
 node nomePrograma.exteçao 
 e se tiver argumentos nomePrograma.exteçao 1 2 3 4 ...*/
console.log("\t\nPrimeiro exemplo\n");
